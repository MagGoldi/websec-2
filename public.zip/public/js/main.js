$(document).ready(function() {
    // Загрузка списков при старте
    loadGroups();
    loadTeachers();
    
    // Обработчики событий
    $('#viewType').change(function() {
        const viewType = $(this).val();
        if (viewType === 'group') {
            $('#groupSelect').show();
            $('#teacherSelect').hide();
        } else {
            $('#groupSelect').hide();
            $('#teacherSelect').show();
        }
    });
    
    $('#groupSelect, #teacherSelect').change(function() {
        const viewType = $('#viewType').val();
        const id = $(this).val();
        if (id) {
            loadSchedule(id, viewType);
        }
    });
    
    $('#weekSelect').change(function() {
        const viewType = $('#viewType').val();
        const id = viewType === 'group' ? $('#groupSelect').val() : $('#teacherSelect').val();
        if (id) {
            loadSchedule(id, viewType);
        }
    });
});

function loadGroups() {
    $.ajax({
        url: '/api/groups',
        method: 'GET',
        success: function(groups) {
            const select = $('#groupSelect');
            select.empty().append('<option value="">Выберите группу</option>');
            for (const [groupName, groupId] of Object.entries(groups)) {
                select.append(`<option value="${groupId}">${groupName}</option>`);
            }
        },
        error: function() {
            alert('Ошибка при загрузке списка групп');
        }
    });
}

function loadTeachers() {
    $.ajax({
        url: '/api/teachers',
        method: 'GET',
        success: function(teachers) {
            const select = $('#teacherSelect');
            select.empty().append('<option value="">Выберите преподавателя</option>');
            for (const [teacherName, teacherId] of Object.entries(teachers)) {
                select.append(`<option value="${teacherId.split('=')[1]}">${teacherName}</option>`);
            }
        },
        error: function() {
            alert('Ошибка при загрузке списка преподавателей');
        }
    });
}

function loadSchedule(id, type) {
    const week = $('#weekSelect').val();
    
    // Показываем индикатор загрузки
    $('#scheduleTable tbody').html('<tr><td colspan="7" class="loading">Загрузка расписания...</td></tr>');
    
    $.ajax({
        url: `/api/schedule/${id}?week=${week}&type=${type}`,
        method: 'GET',
        success: function(data) {
            updateScheduleTable(data);
        },
        error: function() {
            $('#scheduleTable tbody').html('<tr><td colspan="7" class="error">Ошибка при загрузке расписания</td></tr>');
        }
    });
}

function updateScheduleTable(schedule) {
    const tbody = $('#scheduleTable tbody');
    tbody.empty();
    
    // Создаем массив для хранения пар по времени
    const timeSlots = {};
    
    // Собираем все временные слоты
    Object.values(schedule.days).forEach(day => {
        day.forEach(lesson => {
            if (!timeSlots[lesson.time]) {
                timeSlots[lesson.time] = {
                    time: lesson.time,
                    lessons: {}
                };
            }
        });
    });
    
    // Заполняем расписание по дням
    const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const dayNames = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота'];
    
    days.forEach((day, index) => {
        schedule.days[day].forEach(lesson => {
            timeSlots[lesson.time].lessons[dayNames[index]] = lesson.info;
        });
    });
    
    // Сортируем временные слоты
    const sortedTimeSlots = Object.values(timeSlots).sort((a, b) => {
        return a.time.localeCompare(b.time);
    });
    
    // Создаем строки таблицы
    sortedTimeSlots.forEach(slot => {
        const row = $('<tr>');
        row.append(`<td class="time-cell">${slot.time}</td>`);
        
        // Добавляем ячейки для каждого дня
        dayNames.forEach(dayName => {
            const lessonInfo = slot.lessons[dayName];
            if (lessonInfo) {
                const cell = $(`
                    <td class="lesson-cell">
                        <div class="lesson-info">${lessonInfo}</div>
                    </td>
                `);
                row.append(cell);
            } else {
                row.append('<td class="empty-cell"></td>');
            }
        });
        
        tbody.append(row);
    });
    
    // Если расписание пустое
    if (tbody.children().length === 0) {
        tbody.html('<tr><td colspan="7" class="empty">Расписание отсутствует</td></tr>');
    }
} 